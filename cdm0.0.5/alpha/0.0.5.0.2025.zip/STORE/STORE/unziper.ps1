﻿param(
    [string]$froms,
    [string]$tos
)
Expand-Archive -Path $froms -DestinationPath $tos